export default class {
    persist(account) {
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
    merge(account) {
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
    remove(accountId) {
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
    get(accountId) {
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
    find(query){
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
}