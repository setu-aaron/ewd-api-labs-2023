// {
//     "id": 28,
//     "name": "Action"
// }

export default class {
    constructor (id = undefined, tmdbId, name){
        this.id = id;
        this.tmdbId = tmdbId;
        this.name = name;
    }
}