export default class {
    encrypt(password){
        throw new Error ('ERR_METHOD_NOT_IMPLMENTED');
    }

    compare(password, encryptedPassword){
        throw new Error ('ERR_METHOD_NOT_IMPLMENTED');
    }
}