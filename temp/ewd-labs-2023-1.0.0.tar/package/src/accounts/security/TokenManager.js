export default class {
    generate() {
        throw new Error('ERROR_METHOD_NOT_IMPLEMENTED');
    }
    decode() {
        throw new Error('ERROR_METHOD_NOT_IMPLEMENTED');
    }
}